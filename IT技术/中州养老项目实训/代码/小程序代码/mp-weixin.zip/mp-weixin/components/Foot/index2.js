"use strict";
const index = require("../../index.js");
require("../../common/vendor.js");
wx.createComponent(index.Component);
