"use strict";
const index = require("../../index.js");
require("../../common/vendor.js");
wx.createPage(index.Component);
