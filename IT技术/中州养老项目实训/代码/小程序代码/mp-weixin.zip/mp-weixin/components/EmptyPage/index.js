"use strict";
const common_vendor = require("../../common/vendor.js");
const _sfc_main = {
  __name: "index",
  props: {
    emptyInfo: {
      type: String,
      default: ""
    }
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return {};
    };
  }
};
const Component = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["__scopeId", "data-v-e3eb26b5"], ["__file", "D:/project/2024/java/project-zhyl-xcx-uniapp-java-gaowendong/components/EmptyPage/index.vue"]]);
wx.createComponent(Component);
