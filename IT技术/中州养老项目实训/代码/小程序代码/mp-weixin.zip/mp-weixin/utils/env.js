"use strict";
const baseUrl = "http://localhost:9995/customer";
exports.baseUrl = baseUrl;
